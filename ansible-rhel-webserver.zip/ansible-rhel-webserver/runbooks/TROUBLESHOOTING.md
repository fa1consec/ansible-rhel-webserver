# Apache troubleshooting runbook (RHEL)

Use this checklist when the site does not load or the Ansible deployment reports an error.

## 1. Check service state

```bash
sudo systemctl status httpd --no-pager
sudo systemctl status firewalld --no-pager
sudo systemctl status crond --no-pager
```

## 2. Read service logs

```bash
sudo journalctl -u httpd -b --no-pager -n 100
sudo journalctl -u firewalld -b --no-pager -n 100
```

## 3. Validate Apache configuration

```bash
sudo apachectl configtest
sudo httpd -S
```

Resolve any reported syntax error before restarting or reloading Apache.

## 4. Check the firewall

```bash
sudo firewall-cmd --get-active-zones
sudo firewall-cmd --zone=public --list-services
```

The zone in the second command should match `firewalld_zone` in
`group_vars/webservers.yml`, and the HTTP service should be listed.

## 5. Test the site locally

Replace `web.example.com` with the value of `server_name`:

```bash
curl -i -H 'Host: web.example.com' http://127.0.0.1/
curl -i -H 'Host: web.example.com' http://127.0.0.1/healthz
```

The health endpoint should return HTTP 200 and the text `ok`.

## 6. Investigate SELinux denials without disabling SELinux

```bash
getenforce
sudo ausearch -m AVC,USER_AVC -ts recent
sudo journalctl -t setroubleshoot --since '30 minutes ago'
```

Review the denial and correct the file context or policy for the specific resource.
Do not use `setenforce 0` or disable SELinux as a routine troubleshooting step.

## 7. Check scheduled health-check execution

```bash
sudo crontab -l
sudo tail -n 50 /var/log/rhel_demo-maintenance.log
```

Adjust the log path in the command if `app_name` is not `rhel_demo`.

## 8. Re-run Ansible safely

From the repository root:

```bash
ansible-playbook --syntax-check site.yml
ansible-playbook --check --diff site.yml
ansible-playbook site.yml
```

Capture the failing task and relevant service logs when documenting the incident.
