# Automated Linux Web Server Deployment on RHEL with Ansible

An Ansible project that configures an Apache HTTP Server on a RHEL-compatible
host. It installs and enables Apache, creates a dedicated application content
owner, deploys a virtual host and sample HTML page, opens HTTP in firewalld,
and schedules a non-destructive HTTP health check.

## What it configures

- Apache HTTP Server (`httpd`), `firewalld`, and the cron daemon (`crond`).
- A dedicated system account that owns the deployed web content.
- An Apache virtual host using a configurable `ServerName` and document root.
- A sample home page and `/healthz` endpoint.
- The HTTP firewalld service in a configurable zone.
- A root cron job that checks the local `/healthz` endpoint and records the
  result in `/var/log/<app_name>-maintenance.log`.
- An Apache troubleshooting runbook using `systemctl`, `journalctl`,
  `apachectl`, `firewall-cmd`, `curl`, and SELinux audit tools.

## Repository layout

```text
.
├── ansible.cfg
├── site.yml
├── collections/
│   └── requirements.yml
├── inventory/
│   └── hosts.ini.example
├── group_vars/
│   └── webservers.yml
├── roles/
│   └── rhel_webserver/
│       ├── defaults/main.yml
│       ├── handlers/main.yml
│       ├── tasks/main.yml
│       └── templates/
│           ├── index.html.j2
│           ├── maintenance.sh.j2
│           └── vhost.conf.j2
└── runbooks/
    └── TROUBLESHOOTING.md
```

## Requirements

- Ansible Core on the control node.
- SSH access to the target RHEL server.
- A target account with sudo privileges.
- RHEL 8/9/10 or a compatible distribution with `dnf`, `httpd`, and
  `firewalld`. Package names and service defaults can vary on derivatives.
- The `ansible.posix` collection.

Install the collection:

```bash
ansible-galaxy collection install -r collections/requirements.yml
```

## Configure inventory

Copy the example inventory and edit it for your server:

```bash
cp inventory/hosts.ini.example inventory/hosts.ini
```

Update `ansible_host` and `ansible_user`. The example uses `ec2-user`; replace
that with the SSH account for your environment. Make sure that account can use
sudo. The local inventory is excluded from Git by `.gitignore`.

## Configure the site

Edit `group_vars/webservers.yml`:

```yaml
app_name: rhel_demo
server_name: web.example.com
app_user: webapp
firewalld_zone: public
maintenance_cron_minute: "*/15"
maintenance_cron_hour: "*"
```

Point `server_name` at the DNS name you intend to use. Ensure that the
`firewalld_zone` value matches the active zone on the target server. This
example serves HTTP on port 80; add TLS and certificate management before
using it for a public production site.

## Run the playbook

Check that Ansible can see the target:

```bash
ansible-inventory --graph
ansible all -m ping
```

Check syntax, preview changes, then apply:

```bash
ansible-playbook --syntax-check site.yml
ansible-playbook --check --diff site.yml
ansible-playbook site.yml
```

The first run may require SSH key setup or an interactive become password.
Do not commit passwords, private keys, or Ansible Vault password files. Store
secrets in Ansible Vault or an approved secrets manager.

## Verify deployment

On the target server:

```bash
sudo systemctl is-active httpd
sudo systemctl is-active firewalld
sudo apachectl configtest
sudo firewall-cmd --zone=public --list-services
```

From a machine that can reach the server, test the virtual host (replace the
address and hostname):

```bash
curl -i -H 'Host: web.example.com' http://192.0.2.10/
curl -i -H 'Host: web.example.com' http://192.0.2.10/healthz
```

The health endpoint should return HTTP 200 with `ok`. The scheduled check logs
a success or failure on the target server:

```bash
sudo tail -n 20 /var/log/rhel_demo-maintenance.log
sudo crontab -l
```

## Troubleshooting

See [`runbooks/TROUBLESHOOTING.md`](runbooks/TROUBLESHOOTING.md) for the
step-by-step checks for service status, journal logs, Apache syntax, firewall,
HTTP response, SELinux denials, and cron execution.

## Important notes

- This is a demonstration project for a lab or portfolio. Review it against
  your organization's security baseline before production use.
- The playbook manages the files it creates under `/etc/httpd/conf.d/`, the
  selected document root, and the maintenance script/log paths.
- The health check is non-destructive; it does not delete files or modify
  application data.
- The playbook does not configure HTTPS, DNS, external load balancers, or
  application-specific deployment pipelines.
- Test on a disposable VM first, then adapt variables and firewall rules for
  your environment.
